<?php $__env->startSection('title', $asset->exists ? 'Edit Purchase' : 'Add Purchase'); ?>
<?php $__env->startSection('breadcrumb', 'Purchase Register'); ?>

<?php $__env->startSection('content'); ?>

<div class="mx-auto max-w-7xl">

    <!-- Page Header -->
    <div class="mb-8 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">

        <div>
            <div class="mb-2 text-xs font-bold tracking-[0.2em] text-blue-600">
                PURCHASE REGISTER
            </div>

            <h1 class="text-2xl font-bold text-slate-900 sm:text-3xl">
                <?php echo e($asset->exists ? 'Edit Purchase' : 'Add Purchase'); ?>

            </h1>

            <p class="mt-2 text-sm text-slate-500">
                Enter the purchase details exactly as shown on the invoice/register.
            </p>
        </div>

        <a
            href="<?php echo e($asset->exists ? route('assets.show', $asset) : route('assets.index')); ?>"
            class="inline-flex items-center justify-center rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50">

            ← Back
        </a>

    </div>


    <!-- Form -->
    <div class="rounded-2xl border border-slate-200 bg-white shadow-sm">

        <form
            method="POST"
            enctype="multipart/form-data"
            action="<?php echo e($asset->exists ? route('assets.update', $asset) : route('assets.store')); ?>">

            <?php echo csrf_field(); ?>

            <?php if($asset->exists): ?>
            <?php echo method_field('PUT'); ?>
            <?php endif; ?>


            <div class="border-b border-slate-200 px-6 py-5 sm:px-8">

                <h2 class="text-lg font-bold text-slate-900">
                    Purchase Information
                </h2>

                <p class="mt-1 text-sm text-slate-500">
                    Fields marked with * are required.
                </p>

            </div>


            <div class="space-y-8 px-6 py-6 sm:px-8">

                <!-- Basic Information -->
                <div>

                    <h3 class="mb-5 text-sm font-bold uppercase tracking-wider text-slate-700">
                        Basic Information
                    </h3>

                    <div class="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">

                        <!-- Particular Items -->
                        <div class="lg:col-span-2">

                            <label class="mb-2 block text-sm font-semibold text-slate-700">
                                Particular Items <span class="text-red-500">*</span>
                            </label>

                            <input
                                type="text"
                                name="particular_items"
                                required
                                maxlength="255"
                                value="<?php echo e(old('particular_items', $asset->particular_items)); ?>"
                                class="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100">

                        </div>


                        <!-- Category -->
                        <div>

                            <label class="mb-2 block text-sm font-semibold text-slate-700">
                                Category <span class="text-red-500">*</span>
                            </label>

                            <select
                                name="category_id"
                                required
                                class="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100">

                                <option value="">Select category</option>

                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option
                                    value="<?php echo e($c->id); ?>"
                                    <?php if(old('category_id', $asset->category_id) == $c->id): echo 'selected'; endif; ?>>

                                    <?php echo e($c->name); ?>


                                </option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                        </div>


                        <!-- Supplier -->
                        <div>

                            <label class="mb-2 block text-sm font-semibold text-slate-700">
                                Purchased From
                            </label>

                            <select
                                name="supplier_id"
                                class="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100">

                                <option value="">Select supplier</option>

                                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option
                                    value="<?php echo e($s->id); ?>"
                                    <?php if(old('supplier_id', $asset->supplier_id) == $s->id): echo 'selected'; endif; ?>>

                                    <?php echo e($s->name); ?>


                                </option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                        </div>


                        <!-- Purchase Date -->
                        <div>

                            <label class="mb-2 block text-sm font-semibold text-slate-700">
                                Purchase Date <span class="text-red-500">*</span>
                            </label>

                            <input
                                type="date"
                                name="purchase_date"
                                required
                                value="<?php echo e(old('purchase_date', $asset->purchase_date?->format('Y-m-d'))); ?>"
                                class="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100">

                        </div>


                        <!-- Invoice -->
                        <div>

                            <label class="mb-2 block text-sm font-semibold text-slate-700">
                                Invoice No
                            </label>

                            <input
                                type="text"
                                name="invoice_no"
                                value="<?php echo e(old('invoice_no', $asset->invoice_no)); ?>"
                                class="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100">

                        </div>

                    </div>

                </div>


                <!-- Item Details -->
                <div class="border-t border-slate-200 pt-8">

                    <h3 class="mb-5 text-sm font-bold uppercase tracking-wider text-slate-700">
                        Item Details
                    </h3>

                    <div class="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">

                        <div>

                            <label class="mb-2 block text-sm font-semibold text-slate-700">
                                Serial Number
                            </label>

                            <input
                                name="serial_number"
                                value="<?php echo e(old('serial_number', $asset->serial_number)); ?>"
                                class="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100">

                        </div>


                        <div>

                            <label class="mb-2 block text-sm font-semibold text-slate-700">
                                Brand Name
                            </label>

                            <input
                                name="brand_name"
                                value="<?php echo e(old('brand_name', $asset->brand_name)); ?>"
                                class="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100">

                        </div>


                        <div>

                            <label class="mb-2 block text-sm font-semibold text-slate-700">
                                Warranty
                            </label>

                            <input
                                name="warranty"
                                placeholder="e.g. 1 Year, 6 Months"
                                value="<?php echo e(old('warranty', $asset->warranty)); ?>"
                                class="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100">

                        </div>

                    </div>

                </div>


                <!-- Price Information -->
                <div class="border-t border-slate-200 pt-8">

                    <h3 class="mb-5 text-sm font-bold uppercase tracking-wider text-slate-700">
                        Quantity & Price
                    </h3>

                    <div class="grid grid-cols-1 gap-5 md:grid-cols-3">

                        <div>

                            <label class="mb-2 block text-sm font-semibold text-slate-700">
                                Qty <span class="text-red-500">*</span>
                            </label>

                            <input
                                type="number"
                                step="0.01"
                                min="0.01"
                                name="qty"
                                required
                                value="<?php echo e(old('qty', $asset->qty ?? 1)); ?>"
                                class="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100">

                        </div>


                        <div>

                            <label class="mb-2 block text-sm font-semibold text-slate-700">
                                Unit Price <span class="text-red-500">*</span>
                            </label>

                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                name="unit_price"
                                required
                                value="<?php echo e(old('unit_price', $asset->unit_price ?? 0)); ?>"
                                class="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100">

                        </div>


                        <div>

                            <label class="mb-2 block text-sm font-semibold text-slate-700">
                                Total Price <span class="text-red-500">*</span>
                            </label>

                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                name="total_price"
                                required
                                value="<?php echo e(old('total_price', $asset->total_price ?? 0)); ?>"
                                class="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm font-semibold outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100">

                            <p class="mt-2 text-xs text-slate-500">
                                Enter the invoice total manually. The system will not multiply quantity × unit price.
                            </p>

                        </div>

                    </div>

                </div>


                <!-- Other Information -->
                <div class="border-t border-slate-200 pt-8">

                    <div class="grid grid-cols-1 gap-5 md:grid-cols-2">

                        <div>

                            <label class="mb-2 block text-sm font-semibold text-slate-700">
                                Received By
                            </label>

                            <input
                                name="received_by"
                                value="<?php echo e(old('received_by', $asset->received_by)); ?>"
                                class="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100">

                        </div>


                        <div>

                            <label class="mb-2 block text-sm font-semibold text-slate-700">
                                Remarks
                            </label>

                            <textarea
                                name="remarks"
                                rows="4"
                                class="w-full resize-none rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100"><?php echo e(old('remarks', $asset->remarks)); ?></textarea>

                        </div>

                    </div>

                </div>


                <!-- Attachments -->
                <div class="border-t border-slate-200 pt-8">

                    <h3 class="mb-5 text-sm font-bold uppercase tracking-wider text-slate-700">
                        Attachments
                    </h3>

                    <div class="grid grid-cols-1 gap-5 md:grid-cols-2">

                        <div class="rounded-xl border border-dashed border-slate-300 p-5">

                            <label class="mb-2 block text-sm font-semibold text-slate-700">
                                Invoice Attachments
                            </label>

                            <input
                                type="file"
                                name="invoice_files[]"
                                multiple
                                accept=".pdf,.jpg,.jpeg,.png,.webp"
                                class="block w-full text-sm text-slate-500">

                            <p class="mt-2 text-xs text-slate-500">
                                PDF or Image · Maximum 5 MB each · Up to 5 files
                            </p>

                        </div>


                        <div class="rounded-xl border border-dashed border-slate-300 p-5">

                            <label class="mb-2 block text-sm font-semibold text-slate-700">
                                Item Images
                            </label>

                            <input
                                type="file"
                                name="item_images[]"
                                multiple
                                accept="image/jpeg,image/png,image/webp"
                                class="block w-full text-sm text-slate-500">

                            <p class="mt-2 text-xs text-slate-500">
                                Maximum 10 MB each. Images may be converted to WebP.
                            </p>

                        </div>

                    </div>


                    <?php if($asset->exists && $asset->attachments->count()): ?>

                    <div class="mt-6 rounded-xl bg-slate-50 p-5">

                        <h4 class="mb-3 text-sm font-bold text-slate-800">
                            Existing Attachments
                        </h4>

                        <div class="space-y-2">

                            <?php $__currentLoopData = $asset->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <a
                                href="<?php echo e(route('attachments.show', $file)); ?>"
                                class="flex items-center justify-between rounded-lg bg-white p-3 text-sm text-blue-600 transition hover:bg-blue-50">

                                <span class="truncate">
                                    <?php echo e($file->original_file_name); ?>

                                </span>

                                <span class="ml-3 text-xs text-slate-400">
                                    <?php echo e($file->attachment_type); ?>

                                </span>

                            </a>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                    </div>

                    <?php endif; ?>

                </div>

            </div>


            <!-- Actions -->
            <div class="flex flex-col-reverse gap-3 border-t border-slate-200 bg-slate-50 px-6 py-5 sm:flex-row sm:justify-end sm:px-8">

                <a
                    href="<?php echo e($asset->exists ? route('assets.show', $asset) : route('assets.index')); ?>"
                    class="inline-flex items-center justify-center rounded-xl border border-slate-300 bg-white px-5 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-100">

                    Cancel

                </a>

                <button
                    type="submit"
                    class="inline-flex items-center justify-center rounded-xl bg-blue-600 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-blue-600/20 transition hover:bg-blue-700">

                    <?php echo e($asset->exists ? 'Update Purchase' : 'Save Purchase'); ?>


                </button>

            </div>

        </form>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\zztlProjectAsset\laravel-app\resources\views/assets/form.blade.php ENDPATH**/ ?>