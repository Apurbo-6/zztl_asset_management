

<?php $__env->startSection('title', 'Asset Assignments'); ?>
<?php $__env->startSection('breadcrumb', 'Asset Assignments'); ?>

<?php $__env->startSection('content'); ?>

    <div class="mb-8 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">

        <div>

            <div class="text-xs font-bold tracking-widest text-blue-600">
                ASSET MANAGEMENT
            </div>

            <h1 class="mt-2 text-2xl font-bold text-slate-900">
                Asset Assignments
            </h1>

            <p class="mt-1 text-sm text-slate-500">
                Track assets assigned to departments and personnel.
            </p>

        </div>


        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asset_assignments.create')): ?>
            <a href="<?php echo e(route('asset-assignments.create')); ?>"
                class="inline-flex items-center justify-center rounded-xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700">

                + Assign Asset

            </a>
        <?php endif; ?>

    </div>


    <!-- Filters -->
    <div class="mb-6 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">

        <form method="GET" class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-5">

            <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Asset, serial, person..."
                class="rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none focus:border-blue-500">


            <select name="department_id"
                class="rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none focus:border-blue-500">

                <option value="">
                    All Departments
                </option>

                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($department->id); ?>" <?php if(request('department_id') == $department->id): echo 'selected'; endif; ?>>

                        <?php echo e($department->name); ?>


                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>


            <select name="status"
                class="rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none focus:border-blue-500">

                <option value="">
                    All Status
                </option>

                <option value="assigned" <?php if(request('status') === 'assigned'): echo 'selected'; endif; ?>>
                    Assigned
                </option>

                <option value="returned" <?php if(request('status') === 'returned'): echo 'selected'; endif; ?>>
                    Returned
                </option>

            </select>


            <button type="submit"
                class="rounded-xl bg-slate-900 px-4 py-3 text-sm font-semibold text-white hover:bg-slate-800">

                Search

            </button>


            <a href="<?php echo e(route('asset-assignments.index')); ?>"
                class="rounded-xl border border-slate-300 px-4 py-3 text-center text-sm font-semibold text-slate-700 hover:bg-slate-50">

                Reset

            </a>

        </form>

    </div>


    <!-- Assignment Table -->
    <div class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">

        <div class="overflow-x-auto">

            <table class="w-full min-w-[1100px] text-left text-sm">

                <thead class="bg-slate-50 text-xs font-bold uppercase tracking-wide text-slate-500">

                    <tr>

                        <th class="px-6 py-4">Asset</th>
                        <th class="px-6 py-4">Serial Number</th>
                        <th class="px-6 py-4">Department</th>
                        <th class="px-6 py-4">Assigned To</th>
                        <th class="px-6 py-4">Assigned Date</th>
                        <th class="px-6 py-4">Status</th>
                        <th class="px-6 py-4 text-right">Action</th>

                    </tr>

                </thead>


                <tbody class="divide-y divide-slate-100">

                    <?php $__empty_1 = true; $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="transition hover:bg-slate-50">

                            <td class="px-6 py-4">

                                <a href="<?php echo e(route('assets.show', $assignment->asset)); ?>"
                                    class="font-semibold text-slate-900 hover:text-blue-600">

                                    <?php echo e($assignment->asset?->particular_items ?? '—'); ?>


                                </a>

                            </td>


                            <td class="px-6 py-4 font-mono text-xs text-slate-600">

                                <?php echo e($assignment->asset?->serial_number ?: '—'); ?>


                            </td>


                            <td class="px-6 py-4 text-slate-600">

                                <?php echo e($assignment->department?->name ?? '—'); ?>


                            </td>


                            <td class="px-6 py-4 font-medium text-slate-700">

                                <?php echo e($assignment->assigned_to ?: '—'); ?>


                            </td>


                            <td class="px-6 py-4 text-slate-600">

                                <?php echo e($assignment->assigned_date?->format('d M Y')); ?>


                            </td>


                            <td class="px-6 py-4">

                                <?php if($assignment->status === 'assigned'): ?>
                                    <span class="rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700">
                                        Assigned
                                    </span>
                                <?php else: ?>
                                    <span class="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600">
                                        Returned
                                    </span>
                                <?php endif; ?>

                            </td>


                            <td class="px-6 py-4 text-right">

                                <a href="<?php echo e(route('asset-assignments.edit', $assignment)); ?>"
                                    class="font-semibold text-blue-600 hover:text-blue-800">

                                    Manage →

                                </a>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>

                            <td colspan="7" class="px-6 py-12 text-center text-slate-500">

                                No asset assignments found.

                            </td>

                        </tr>
                    <?php endif; ?>

                </tbody>

            </table>

        </div>


        <?php if(method_exists($assignments, 'links')): ?>
            <div class="border-t border-slate-200 px-6 py-4">

                <?php echo e($assignments->links()); ?>


            </div>
        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\zztlProjectAsset\laravel-app\resources\views/asset-assignments/index.blade.php ENDPATH**/ ?>