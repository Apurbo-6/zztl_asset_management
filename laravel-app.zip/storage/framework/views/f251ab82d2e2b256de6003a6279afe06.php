

<?php $__env->startSection('title', 'Edit Purchase'); ?>
<?php $__env->startSection('breadcrumb', 'Edit Purchase'); ?>

<?php $__env->startSection('content'); ?>

    <div class="mb-8 flex items-start justify-between">

        <div>

            <div class="text-xs font-bold tracking-widest text-blue-600">
                PURCHASE MANAGEMENT
            </div>

            <h1 class="mt-2 text-2xl font-bold text-slate-900">
                Edit Purchase
            </h1>

            <p class="mt-1 text-sm text-slate-500">
                Update the purchase invoice information.
            </p>

        </div>

        <a href="<?php echo e(route('purchases.show', $purchase)); ?>"
            class="rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50">

            ← Back

        </a>

    </div>


    <div class="max-w-4xl rounded-2xl border border-slate-200 bg-white p-6 shadow-sm md:p-8">

        <form method="POST" action="<?php echo e(route('purchases.update', $purchase)); ?>" class="space-y-6">

            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>


            <!-- Supplier -->
            <div>

                <label class="mb-2 block text-sm font-semibold text-slate-700">

                    Supplier

                </label>

                <select name="supplier_id"
                    class="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-100">

                    <option value="">
                        Select Supplier
                    </option>

                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($supplier->id); ?>" <?php if(old('supplier_id', $purchase->supplier_id) == $supplier->id): echo 'selected'; endif; ?>>

                            <?php echo e($supplier->name); ?>


                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>

            </div>


            <div class="grid grid-cols-1 gap-6 md:grid-cols-2">

                <!-- Invoice -->
                <div>

                    <label class="mb-2 block text-sm font-semibold text-slate-700">

                        Invoice Number

                    </label>

                    <input type="text" name="invoice_no" value="<?php echo e(old('invoice_no', $purchase->invoice_no)); ?>"
                        placeholder="Enter invoice number"
                        class="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-100">

                </div>


                <!-- Date -->
                <div>

                    <label class="mb-2 block text-sm font-semibold text-slate-700">

                        Purchase Date <span class="text-red-500">*</span>

                    </label>

                    <input type="date" name="purchase_date"
                        value="<?php echo e(old('purchase_date', optional($purchase->purchase_date)->format('Y-m-d'))); ?>" required
                        class="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-100">

                </div>

            </div>


            <!-- Remarks -->
            <div>

                <label class="mb-2 block text-sm font-semibold text-slate-700">

                    Remarks

                </label>

                <textarea name="remarks" rows="4" placeholder="Additional purchase information..."
                    class="w-full resize-none rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-100"><?php echo e(old('remarks', $purchase->remarks)); ?></textarea>

            </div>


            <div class="flex flex-col-reverse gap-3 border-t border-slate-200 pt-6 sm:flex-row sm:justify-end">

                <a href="<?php echo e(route('purchases.show', $purchase)); ?>"
                    class="rounded-xl border border-slate-300 px-5 py-3 text-center text-sm font-semibold text-slate-700 hover:bg-slate-50">

                    Cancel

                </a>

                <button type="submit"
                    class="rounded-xl bg-blue-600 px-6 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700">

                    Update Purchase

                </button>

            </div>

        </form>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\zztlProjectAsset\laravel-app\resources\views/purchases/edit.blade.php ENDPATH**/ ?>