<?php $__env->startSection('title', $category->exists ? 'Edit Category' : 'Add Category'); ?>
<?php $__env->startSection('breadcrumb', 'Categories'); ?>

<?php $__env->startSection('content'); ?>

<div class="mx-auto max-w-3xl">

    <!-- Page Header -->
    <div class="mb-8">

        <div class="mb-2 text-xs font-bold tracking-[0.2em] text-blue-600">
            MASTER DATA
        </div>

        <h1 class="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
            <?php echo e($category->exists ? 'Edit Category' : 'Add Category'); ?>

        </h1>

        <p class="mt-2 text-sm text-slate-500">
            <?php echo e($category->exists
                ? 'Update the category information below.'
                : 'Create a new purchase item category for the asset management system.'); ?>

        </p>

    </div>


    <!-- Form Card -->
    <div class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">

        <!-- Card Header -->
        <div class="border-b border-slate-200 px-6 py-5">

            <h2 class="text-base font-semibold text-slate-900">
                Category Information
            </h2>

            <p class="mt-1 text-sm text-slate-500">
                Fields marked with * are required.
            </p>

        </div>


        <form
            method="POST"
            action="<?php echo e($category->exists
                ? route('categories.update', $category)
                : route('categories.store')); ?>"
            class="p-6">

            <?php echo csrf_field(); ?>

            <?php if($category->exists): ?>
            <?php echo method_field('PUT'); ?>
            <?php endif; ?>


            <!-- Category Name -->
            <div>

                <label
                    for="name"
                    class="mb-2 block text-sm font-semibold text-slate-700">

                    Category Name
                    <span class="text-red-500">*</span>

                </label>


                <input
                    id="name"
                    type="text"
                    name="name"
                    required
                    maxlength="150"
                    value="<?php echo e(old('name', $category->name)); ?>"
                    placeholder="Enter category name"

                    class="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-blue-500 focus:ring-4 focus:ring-blue-100 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 focus:border-red-500 focus:ring-red-100 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">


                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                <p class="mt-2 text-sm font-medium text-red-600">
                    <?php echo e($message); ?>

                </p>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>


            <!-- Active Status -->
            <?php if($category->exists): ?>

            <div class="mt-6">

                <label class="flex cursor-pointer items-center gap-3">

                    <input
                        type="checkbox"
                        name="is_active"
                        value="1"

                        <?php if(old('is_active', $category->is_active)): echo 'checked'; endif; ?>

                    class="h-5 w-5 rounded border-slate-300 text-blue-600 focus:ring-blue-500">


                    <div>

                        <div class="text-sm font-semibold text-slate-700">
                            Active Category
                        </div>

                        <div class="mt-0.5 text-xs text-slate-500">
                            Enable this category for future purchase records.
                        </div>

                    </div>

                </label>

            </div>

            <?php endif; ?>


            <!-- Actions -->
            <div class="mt-8 flex flex-col-reverse gap-3 border-t border-slate-200 pt-6 sm:flex-row sm:items-center sm:justify-end">

                <a
                    href="<?php echo e(route('categories.index')); ?>"

                    class="inline-flex items-center justify-center rounded-xl border border-slate-300 bg-white px-5 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 hover:text-slate-900">

                    Cancel

                </a>


                <button
                    type="submit"

                    class="inline-flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-blue-600/20 transition hover:bg-blue-700 hover:shadow-xl active:scale-[0.98]">

                    <!-- Save Icon -->
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        class="h-5 w-5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        stroke-width="2">

                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            d="M5 13l4 4L19 7" />

                    </svg>

                    <?php echo e($category->exists ? 'Update Category' : 'Save Category'); ?>


                </button>

            </div>

        </form>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\zztlProjectAsset\laravel-app\resources\views/categories/form.blade.php ENDPATH**/ ?>