

<?php $__env->startSection('title', 'Purchases'); ?>
<?php $__env->startSection('breadcrumb', 'Purchases'); ?>

<?php $__env->startSection('content'); ?>

    <div class="space-y-6">

        <!-- Page Header -->
        <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">

            <div>
                <div class="text-xs font-bold tracking-widest text-blue-600">
                    PURCHASE MANAGEMENT
                </div>

                <h1 class="mt-1 text-2xl font-bold text-slate-900">
                    Purchases
                </h1>

                <p class="mt-1 text-sm text-slate-500">
                    Manage invoices and purchased assets.
                </p>
            </div>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchases.create')): ?>
                <a href="<?php echo e(route('purchases.create')); ?>"
                    class="inline-flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-blue-200 transition hover:bg-blue-700">
                    <span class="text-lg">+</span>
                    Add Purchase
                </a>
            <?php endif; ?>

        </div>


        <!-- Search -->
        <div class="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">

            <form method="GET" class="flex flex-col gap-3 sm:flex-row">

                <input type="text" name="q" value="<?php echo e(request('q')); ?>"
                    placeholder="Search invoice number or supplier..."
                    class="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-100">

                <button type="submit"
                    class="rounded-xl bg-slate-900 px-6 py-3 text-sm font-semibold text-white transition hover:bg-slate-800">
                    Search
                </button>

                <a href="<?php echo e(route('purchases.index')); ?>"
                    class="rounded-xl border border-slate-300 px-6 py-3 text-center text-sm font-semibold text-slate-600 transition hover:bg-slate-50">
                    Reset
                </a>

            </form>

        </div>


        <!-- Purchase Table -->
        <div class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">

            <div class="overflow-x-auto">

                <table class="min-w-full text-left">

                    <thead class="border-b border-slate-200 bg-slate-50">

                        <tr>

                            <th class="px-5 py-4 text-xs font-bold uppercase tracking-wider text-slate-500">
                                Invoice
                            </th>

                            <th class="px-5 py-4 text-xs font-bold uppercase tracking-wider text-slate-500">
                                Supplier
                            </th>

                            <th class="px-5 py-4 text-xs font-bold uppercase tracking-wider text-slate-500">
                                Purchase Date
                            </th>

                            <th class="px-5 py-4 text-xs font-bold uppercase tracking-wider text-slate-500">
                                Assets
                            </th>

                            <th class="px-5 py-4 text-right text-xs font-bold uppercase tracking-wider text-slate-500">
                                Action
                            </th>

                        </tr>

                    </thead>


                    <tbody class="divide-y divide-slate-100">

                        <?php $__empty_1 = true; $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="transition hover:bg-slate-50">

                                <td class="px-5 py-4">

                                    <a href="<?php echo e(route('purchases.show', $purchase)); ?>"
                                        class="font-semibold text-blue-600 hover:text-blue-800">

                                        <?php echo e($purchase->invoice_no ?: 'No Invoice Number'); ?>


                                    </a>

                                </td>


                                <td class="px-5 py-4 text-sm text-slate-600">

                                    <?php echo e($purchase->supplier?->name ?? 'No Supplier'); ?>


                                </td>


                                <td class="px-5 py-4 text-sm text-slate-600">

                                    <?php echo e($purchase->purchase_date?->format('d M Y')); ?>


                                </td>


                                <td class="px-5 py-4">

                                    <span
                                        class="inline-flex rounded-full bg-blue-50 px-3 py-1 text-xs font-bold text-blue-700">

                                        <?php echo e($purchase->assets->count()); ?> Items

                                    </span>

                                </td>


                                <td class="px-5 py-4">

                                    <div class="flex justify-end gap-2">

                                        <a href="<?php echo e(route('purchases.show', $purchase)); ?>"
                                            class="rounded-lg bg-slate-100 px-3 py-2 text-xs font-semibold text-slate-700 transition hover:bg-slate-200">

                                            View

                                        </a>


                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchases.update')): ?>
                                            <a href="<?php echo e(route('purchases.edit', $purchase)); ?>"
                                                class="rounded-lg bg-blue-50 px-3 py-2 text-xs font-semibold text-blue-700 transition hover:bg-blue-100">

                                                Edit

                                            </a>
                                        <?php endif; ?>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <tr>

                                <td colspan="5" class="px-6 py-14 text-center text-sm text-slate-400">

                                    No purchase records found.

                                </td>

                            </tr>
                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>


        <!-- Pagination -->
        <div>

            <?php echo e($purchases->links()); ?>


        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\zztlProjectAsset\laravel-app\resources\views/purchases/index.blade.php ENDPATH**/ ?>