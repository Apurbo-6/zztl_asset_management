

<?php $__env->startSection('title', 'Purchase Details'); ?>
<?php $__env->startSection('breadcrumb', 'Purchase Details'); ?>

<?php $__env->startSection('content'); ?>

    <div class="mb-8 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">

        <div>
            <div class="text-xs font-bold tracking-widest text-blue-600">
                PURCHASE DETAILS
            </div>

            <h1 class="mt-2 text-2xl font-bold text-slate-900">
                <?php echo e($purchase->invoice_no ?: 'Purchase Record'); ?>

            </h1>

            <p class="mt-1 text-sm text-slate-500">
                View purchase information and individual assets.
            </p>
        </div>

        <div class="flex flex-wrap gap-3">

            <a href="<?php echo e(route('purchases.edit', $purchase)); ?>"
                class="inline-flex items-center justify-center rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700">

                Edit Purchase

            </a>

            <a href="<?php echo e(route('purchases.index')); ?>"
                class="inline-flex items-center justify-center rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50">

                ← Back

            </a>

        </div>

    </div>


    <!-- Purchase Information -->
    <div class="mb-8 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">

        <div class="border-b border-slate-200 px-6 py-5">

            <h2 class="text-lg font-bold text-slate-900">
                Purchase Information
            </h2>

        </div>

        <div class="grid grid-cols-1 gap-6 p-6 md:grid-cols-2 lg:grid-cols-4">

            <div>

                <div class="text-xs font-semibold uppercase tracking-wide text-slate-400">
                    Invoice Number
                </div>

                <div class="mt-2 font-semibold text-slate-900">
                    <?php echo e($purchase->invoice_no ?: '—'); ?>

                </div>

            </div>


            <div>

                <div class="text-xs font-semibold uppercase tracking-wide text-slate-400">
                    Supplier
                </div>

                <div class="mt-2 font-semibold text-slate-900">
                    <?php echo e($purchase->supplier?->name ?? '—'); ?>

                </div>

            </div>


            <div>

                <div class="text-xs font-semibold uppercase tracking-wide text-slate-400">
                    Purchase Date
                </div>

                <div class="mt-2 font-semibold text-slate-900">
                    <?php echo e($purchase->purchase_date?->format('d M Y') ?? '—'); ?>

                </div>

            </div>


            <div>

                <div class="text-xs font-semibold uppercase tracking-wide text-slate-400">
                    Total Items
                </div>

                <div class="mt-2 font-semibold text-slate-900">
                    <?php echo e($purchase->assets->count()); ?>

                </div>

            </div>

        </div>


        <?php if($purchase->remarks): ?>
            <div class="border-t border-slate-200 px-6 py-5">

                <div class="text-xs font-semibold uppercase tracking-wide text-slate-400">
                    Remarks
                </div>

                <div class="mt-2 text-sm text-slate-700">
                    <?php echo e($purchase->remarks); ?>

                </div>

            </div>
        <?php endif; ?>

    </div>


    <!-- Assets -->
    <div class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">

        <div class="flex flex-col gap-4 border-b border-slate-200 px-6 py-5 sm:flex-row sm:items-center sm:justify-between">

            <div>

                <h2 class="text-lg font-bold text-slate-900">
                    Purchased Assets
                </h2>

                <p class="mt-1 text-sm text-slate-500">
                    Individual assets under this purchase invoice.
                </p>

            </div>


            <a href="<?php echo e(route('assets.create', ['purchase_id' => $purchase->id])); ?>"
                class="inline-flex items-center justify-center rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-emerald-700">

                + Add Asset

            </a>

        </div>


        <div class="overflow-x-auto">

            <table class="w-full min-w-[900px] text-left text-sm">

                <thead class="bg-slate-50 text-xs font-bold uppercase tracking-wide text-slate-500">

                    <tr>

                        <th class="px-6 py-4">
                            Asset
                        </th>

                        <th class="px-6 py-4">
                            Category
                        </th>

                        <th class="px-6 py-4">
                            Serial Number
                        </th>

                        <th class="px-6 py-4">
                            Brand
                        </th>

                        <th class="px-6 py-4">
                            Price
                        </th>

                        <th class="px-6 py-4">
                            Status
                        </th>

                        <th class="px-6 py-4 text-right">
                            Action
                        </th>

                    </tr>

                </thead>


                <tbody class="divide-y divide-slate-100">

                    <?php $__empty_1 = true; $__currentLoopData = $purchase->assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="transition hover:bg-slate-50">

                            <td class="px-6 py-4">

                                <a href="<?php echo e(route('assets.show', $asset)); ?>"
                                    class="font-semibold text-slate-900 hover:text-blue-600">

                                    <?php echo e($asset->particular_items); ?>


                                </a>

                            </td>


                            <td class="px-6 py-4 text-slate-600">

                                <?php echo e($asset->category?->name ?? '—'); ?>


                            </td>


                            <td class="px-6 py-4">

                                <span class="font-mono text-xs text-slate-600">

                                    <?php echo e($asset->serial_number ?: '—'); ?>


                                </span>

                            </td>


                            <td class="px-6 py-4 text-slate-600">

                                <?php echo e($asset->brand_name ?: '—'); ?>


                            </td>


                            <td class="px-6 py-4 font-semibold text-slate-800">

                                ৳<?php echo e(number_format($asset->total_price, 2)); ?>


                            </td>


                            <td class="px-6 py-4">

                                <?php if($asset->status === 'assigned'): ?>
                                    <span class="rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700">
                                        Assigned
                                    </span>
                                <?php else: ?>
                                    <span
                                        class="rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                                        Available
                                    </span>
                                <?php endif; ?>

                            </td>


                            <td class="px-6 py-4 text-right">

                                <a href="<?php echo e(route('assets.show', $asset)); ?>"
                                    class="font-semibold text-blue-600 hover:text-blue-800">

                                    View →

                                </a>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>

                            <td colspan="7" class="px-6 py-12 text-center text-slate-500">

                                No assets have been added to this purchase yet.

                            </td>

                        </tr>
                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\zztlProjectAsset\laravel-app\resources\views/purchases/show.blade.php ENDPATH**/ ?>